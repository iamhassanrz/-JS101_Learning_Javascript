
let char="a";


char == "a" || char=="e" || char=="i" || char=="o" || char=="u" ? console.log("Vowel") : console.log("Constant");